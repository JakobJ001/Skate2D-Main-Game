﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace NoFlapBird
{
    class Player
    {
        Texture2D texture;
        public Vector2 position, velocity, acceleration, friction, center;
        float rotation;

        float accelerationfloat = 0.1F;
        float frictionfloat = 0;
        float maxspeed = 20;
        float startspeed = 0;
        float restSpeed = 0;

        //Konstruktor
        public Player(Texture2D texture)
        {
            this.texture = texture;
            position = new Vector2(0, 400);
            velocity = new Vector2(startspeed, 0);
            acceleration = new Vector2(0, 0);
            friction = new Vector2(0, 0);
            frictionfloat = accelerationfloat / 2;
            restSpeed = accelerationfloat;

            center = new Vector2(texture.Width / 2, texture.Height / 2);
        }
        
        public Rectangle Hitbox
        {
            get
            {
                Rectangle hitbox = new Rectangle();
                hitbox.Location = position.ToPoint();

                hitbox.Width = texture.Width;
                hitbox.Height = texture.Height;

                return hitbox;
            }
        }

        public void Update()
        {
            

            //så man kan styra höger/vänster, igenom att ändra på acceleration
            if (Keyboard.GetState().IsKeyDown(Keys.Right))
            {
                acceleration.X = accelerationfloat;
            }      
            else if (Keyboard.GetState().IsKeyDown(Keys.Left))
            {
                acceleration.X = -accelerationfloat;
            }
            //sätter acceleration till 0 om ingen knapp är nedtryckt
            else
            {
                acceleration.X = 0;
            }

            //Spelaren får hastighet igenom att addera velocity med acceleration
            velocity += acceleration;

            // kollar om vel är mindre än restSpeed, stäng av hastighet och friktion, annars sätt friktion
            if (System.Math.Abs(velocity.X) < restSpeed)
            {
                velocity.X = 0;
                friction.X = 0;
            }
            else
            {
                //Friktionen gör alltid kraft mot hållet spelaren åker
                if (velocity.X > 0)
                {
                    friction.X = -frictionfloat;
                }
                else if (velocity.X < 0)
                {
                    friction.X = frictionfloat;
                }
            }

            //Spelaren får friktion
            velocity += friction;

            //Om hastigheten råkar gå över maxhastigheten, så sätts den tillbaks till maxhastigheten
            if (velocity.X > maxspeed)
            {
                velocity.X = maxspeed;
            }

            

            //Spelaren rör på sig och ändrar position
            position += velocity;


        }
        public void Draw(SpriteBatch spriteBatch)
        {
            //            spriteBatch.Draw(texture, position, Color.White);

            spriteBatch.Draw(texture, position, null,
                Color.White, rotation, center,
                1, SpriteEffects.None, 1);
        }
    }
}
